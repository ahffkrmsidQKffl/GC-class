export default {
     namespaced: true,
     state() {
      return {
       msg1: "안녕하세요",
       msg2: "오늘도 좋은 하루",
      };
     },
    };
    