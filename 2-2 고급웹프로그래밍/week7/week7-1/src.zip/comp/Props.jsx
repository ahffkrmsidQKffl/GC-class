import React from 'react';

const Props = () => {
    return (
        <div>
              <h2>Props</h2>
                <ul>
                    <li>props는 상위 컴포넌트에서 하위 컴포넌트로 데이터를 전달해주는 객체입니다. </li>
                    <li>리액트는 사용자 정의 컴포넌트로 작성한 엘리먼트의 JSX 속성과 자식을 해당 컴포넌트에 단일 객체로 전달합니다. 
            props.children이 이 역할을 수행하죠. </li>
                    <li>사령탑인 상위 컴포넌트에서 어떤 데이터를 보낼 것인지를 정하면 이 데이터를 props를 통해 객체 형태로 하위 컴포넌트로 보냅니다.</li>
                </ul>
            
            
            
        </div>
    );
};

export default Props;