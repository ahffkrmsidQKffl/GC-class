import React from 'react';

const Component = () => {
    return (
        <div>
            <h2>Component</h2>
                <ul>
                    <li>리액트로 만들어진 앱을 이루는 최소한의 단위</li>
                    <li>기존의 웹 프레임워크는 MVC방식으로 분리하여 관리하여 각 요소의 의존성이 높아 재활용이 어렵다는 단점이 있었다. 반면 컴포넌트는 MVC의 뷰를 독립적으로 구성하여 재사용을 할 수 있고 이를 통해 새로운 컴포넌트를 쉽게 만들 수 있다.</li>
                    <li>컴포넌트는 데이터(props)를 입력받아 View(state) 상태에 따라 DOM Node를 출력하는 함수.</li>
                    <li>컴포넌트 이름은 항상 대문자로 시작하도록 한다.(리액트는 소문자로 시작하는 컴포넌트를 DOM 태그로 취급하기 때문이다.)</li>
                    <li>UI를 재사용 가능한 개별적인 여러 조각으로 나누고, 각 조각을 개별적으로 나누어 코딩한다.</li>
                    <li>“props”라고 하는 임의의 입력을 받은 후, 화면에 어떻게 표시되는지를 기술하는 React 엘리먼트를 반환한다.</li>
                    <li>props와 state 등의 특징들은 따로 정리 하도록 한다.</li>
                </ul>
        </div>
    );
};

export default Component;