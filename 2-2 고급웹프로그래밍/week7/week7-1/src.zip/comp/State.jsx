import React from 'react';

const State = () => {
    return (
        <div>
            <h2>State</h2>
                <ul>
                    <li>state는 일반 자바스크립트 객체다. </li>
                    <li>state는 렌더링 결과물에 영향을 주는 정보를 갖고 있다.</li>
                    <li>props는 (함수 매개변수처럼) 컴포넌트에 전달되는 반면 state는 (함수 내 선언된 변수처럼) 컴포넌트 안에서 관리한다. </li>
                    <li>React에서 this.props와 this.state는 모두 렌더링된 값을 나타낸다. 다시 말해 현재 화면에 보이는 걸 말한다.</li>
                </ul>
            
             
            
            
        </div>
    );
};

export default State;