const DATAS = [
      { id: 1, name: "당근" },
      { id: 2, name: "감자" },
      { id: 3, name: "호박" },
      { id: 4, name: "고구마" },
      { id: 5, name: "토마토" },
    ];

    export default DATAS;