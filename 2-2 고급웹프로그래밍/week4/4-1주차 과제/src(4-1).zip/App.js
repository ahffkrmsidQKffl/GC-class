import Vegetables from "./comp/Vegetables";
import DATAS from "./comp/DATAS";


  const App = () => {
      return (
        <div>
          {/* Props명 = {Props값} */}
          <Vegetables datas={DATAS} />
        </div>
      );
    };

    export default App;
    