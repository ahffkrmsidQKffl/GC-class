import Header from "./comp/Header";
import Nav from "./comp/Nav";
import Article from "./comp/Article";
function App() {
  const topics = [
    { id: 1, title: "html", body: "html is ..." },
    { id: 2, title: "css", body: "css is ..." },
    { id: 3, title: "javascript", body: "javascript is ..." },
    { id: 4, title: "react", body: "react is ..." },
    { id: 5, title: "nodeJs", body: "nodeJs is ..." },
  ];

  return (
    <div>
      <Header title="React"/>
      <Nav topics={topics}/>
      <Article title="JavaScript" body="React"/>
    </div>
  );
}
export default App;
