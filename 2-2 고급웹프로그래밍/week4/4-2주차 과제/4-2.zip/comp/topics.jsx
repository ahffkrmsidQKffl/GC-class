const topics = [
    { id: 1, title: "html", body: "html is ..." },
    { id: 2, title: "css", body: "css is ..." },
    { id: 3, title: "javascript", body: "javascript is ..." },
    { id: 4, title: "react", body: "react is ..." },
    { id: 5, title: "javascript", body: "javascript is ..." },
    { id: 6, title: "react", body: "react is ..." }
  ];
  
  export default topics;
