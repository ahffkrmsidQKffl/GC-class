const books = [
    {
      id: 1,
      title: 'Clean Code',
      author: '로버트 C. 마틴',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium dolor natus sit atque corrupti pariatur quaerat? Laudantium reprehenderit dolor tempore.',
    },
    {
      id: 2,
      title: '실용주의 프로그래머 20주년 기념판',
      author: '데이비드 토머스, 앤드류 헌트',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium dolor natus sit atque corrupti pariatur quaerat? Laudantium reprehenderit dolor tempore.',
    },
    {
        id: 3,
           title: '밑바닥부터 만드는 컴퓨팅 시스템',
           author: '노암 니산, 시몬 쇼켄',
           description:
             'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium dolor natus sit atque corrupti pariatur quaerat? Laudantium reprehenderit dolor tempore.',
         },
       ]
       
       export default books ;
       
  