import BookList from './comp/Booklist' ;
import "./App.css";

function App() {
  return <BookList />;
}
export default App;
