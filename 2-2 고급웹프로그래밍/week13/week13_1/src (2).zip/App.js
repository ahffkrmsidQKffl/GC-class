import React, { useState, useMemo } from "react";
function App() {
 const [count, setCount1] = useState(0);
  const calculate = () => {  // Render 시 실행
  console.log("함수 실행 .......");
  for(var sum = 0, i=1 ; i <= 1000000000 ; i++) {
   sum = sum + i ;
  }
  console.log('함수 실행 완료');
  return sum;
 };
  const value = useMemo(() => {
  console.log("count 변수 수정할 때만 실행(버튼 1)");
  return calculate();
 }, 
  []);
   return (
      <div>
       <button onClick={() => setCount1(count + 1)}> 	클릭 1 </button>
       <p>
        {count} 번 눌렀어요 값은 {value} <br />
       </p> 
      </div>
     );
    }
    export default App;
    
    