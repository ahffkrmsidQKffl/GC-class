import ReactDOM from "react-dom/client";
import App from "./App";
import { Provider } from "react-redux";
import { legacy_createStore as createStore } from "redux";

const initialState = {
  value: 80,
};

function reducer(state = initialState, action) {
  if (action.type === "증가") {
    return { value: (state.value = state.value + 1) };
  } else if (action.type === "감소") {
    return { value: (state.value = state.value - 1) };
  } else if (action.type === "증가10") {
    return { value: (state.value = state.value + 10) };
  } else if (action.type === "감소10") {
    return { value: (state.value = state.value - 10) };
  } else {
    return { value: state.value };
  }
}

let store = createStore(reducer);
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <Provider store={store}>
    <App />
  </Provider>
);
