import { useSelector, useDispatch } from "react-redux";
function App() {
 const weight = useSelector((state) => state.value);
 const dispatch = useDispatch();
 return (
  <div>
   <p> 저장한 몸무게(App) : {weight} </p>
   <button onClick={() => dispatch({ type: "증가" })}>더하기</button>
   <Comp1 />
   <Comp2 />
   <Comp3 />
  </div>
 );
}
/////////////////////////////////////////////////////////////////////////////
function Comp1() {
 const weight = useSelector((state) => state.value);
 const dispatch = useDispatch();
 return (
  <div>
   <p> 저장한 몸무게(Comp1) : {weight} </p>
   <button onClick={() => dispatch({ type: "감소" })}>감소</button>
  </div>
 );
}
function Comp2() {
   const weight = useSelector((state) => state.value);
   const dispatch = useDispatch();
   return (
    <div>
     <p> 저장한 몸무게(Comp2) : {weight} </p>
     <button onClick={() => dispatch({ type: "증가10" })}>10 증가</button>
    </div>
   );
  }
  /////////////////////////////////////////////////////////////////////////////
  function Comp3() {
   const weight = useSelector((state) => state.value);
   const dispatch = useDispatch();
   return (
    <div>
     <p> 저장한 몸무게(Comp2) : {weight} </p>
     <button onClick={() => dispatch({ type: "감소10" })}>10 감소</button>
    </div>
   );
  }
  export default App;
  