function Footer() {
  return (
    <footer>
      <i>
        Copyright 2023. 지은이 all rights reserved.
        <br />
        연락처 : 010-8906-3946
      </i>
    </footer>
  );
}

export default Footer;
