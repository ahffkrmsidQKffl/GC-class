function Article() {
  return (
    <article>
      <a href="member.html">회원 가입 </a>
      <a href="login.html">로그인 </a>
    </article>
  );
}

export default Article;
