const index = () => {
  return (
    <div id="index">
      김창복을 소개합니다
      <br />
      <img src="/image/index.png" alt="나의 사진!!!" />
    </div>
  );
};

export default index;
