import Contest1 from "../Contest/Contest1";
import Contest2 from "../Contest/Contest2";
import Contest3 from "../Contest/Contest3";

const conests = [
  {
    tab: "Contest1",
    content: <Contest1></Contest1>,
  },
  {
    tab: "Contest2",
    content: <Contest2></Contest2>,
  },
  {
    tab: "Contest3",
    content: <Contest3></Contest3>,
  },
];

export default conests;
