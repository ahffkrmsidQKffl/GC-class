import Career1 from "../Career/Career1";
import Career2 from "../Career/Career2";
import Career3 from "../Career/Career3";

const careers = [
  {
    tab: "아르바이트 및 인턴",
    content: <Career1></Career1>,
  },
  {
    tab: "사회봉사 및 연수",
    content: <Career2></Career2>,
  },
  {
    tab: "자격증 및 그외 스펙",
    content: <Career3></Career3>,
  },
];

export default careers;
