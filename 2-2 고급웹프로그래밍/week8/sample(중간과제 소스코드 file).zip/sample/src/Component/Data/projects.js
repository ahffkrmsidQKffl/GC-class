import Project1 from "../Project/Project1";
import Project2 from "../Project/Project2";
import Project3 from "../Project/Project3";
import Project4 from "../Project/Project4";

const projects = [
  {
    tab: "Project1",
    content: <Project1></Project1>,
  },
  {
    tab: "Project2",
    content: <Project2></Project2>,
  },
  {
    tab: "Project3",
    content: <Project3></Project3>,
  },
  {
    tab: "Project4",
    content: <Project4></Project4>,
  },
];

export default projects;
