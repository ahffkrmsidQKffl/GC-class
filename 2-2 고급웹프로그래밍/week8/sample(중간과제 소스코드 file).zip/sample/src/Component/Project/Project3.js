const Project3 = () => {
  return (
    <div>
      <h1>NodeJs 이용한 Backend Web</h1>
      <img src="/image/node.png" alt="react" />
      <fieldset>
        <legend>프로젝트 개요</legend>
        <ul>
          <li>프로젝트에 대한 내용을 작성</li>
          <li>프로젝트에 대한 내용을 작성</li>
          <li>프로젝트에 대한 내용을 작성</li>
          <li>프로젝트에 대한 내용을 작성</li>
          <li>프로젝트에 대한 내용을 작성</li>
        </ul>
      </fieldset>
    </div>
  );
};

export default Project3;
