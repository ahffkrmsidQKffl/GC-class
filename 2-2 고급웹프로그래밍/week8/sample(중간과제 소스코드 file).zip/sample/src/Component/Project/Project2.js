const Project2 = () => {
  return (
    <div>
      <h1>VueJs 이용한 Frontend Web</h1>
      <img src="/image/vue.png" alt="react" />
      <fieldset>
        <legend>프로젝트 개요</legend>
        <ul>
          <li>프로젝트에 대한 내용을 작성</li>
          <li>프로젝트에 대한 내용을 작성</li>
          <li>프로젝트에 대한 내용을 작성</li>
          <li>프로젝트에 대한 내용을 작성</li>
          <li>프로젝트에 대한 내용을 작성</li>
        </ul>
      </fieldset>
    </div>
  );
};

export default Project2;
