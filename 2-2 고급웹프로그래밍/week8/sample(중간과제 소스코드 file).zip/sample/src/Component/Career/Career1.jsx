
const Career1 = () => {
  return (
    <div>
      <h1>아르바이트 및 인턴</h1>
      <fieldset>
        <legend>아르바이트</legend>
        <ul>
          <li>아르바이트에 대한 내용을 작성</li>
          <li>아르바이트에 대한 내용을 작성</li>
        </ul>
      </fieldset>

      <fieldset>
        <legend>인턴</legend>
        <ul>
          <li>인턴에 대한 내용을 작성</li>
          <li>인턴에 대한 내용을 작성</li>
        </ul>
      </fieldset>
    </div>
  );
};

export default Career1;