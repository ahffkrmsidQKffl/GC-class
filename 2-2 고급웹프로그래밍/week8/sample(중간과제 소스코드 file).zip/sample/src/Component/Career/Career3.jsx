
const Career3 = () => {
  return (
    <div>
      <h1>자격증 및 그외 스펙</h1>
      <fieldset>
        <legend>자격증</legend>
        <ul>
          <li>자격증에 대한 내용을 작성</li>
          <li>자격증에 대한 내용을 작성</li>
        </ul>
      </fieldset>

      <fieldset>
        <legend>그외 스펙</legend>
        <ul>
          <li>스펙에 대한 내용을 작성</li>
          <li>스펙에 대한 내용을 작성</li>
        </ul>
      </fieldset>
    </div>
  );
};

export default Career3;