const Career2 = () => {
  return (
    <div>
      <h1>사회 봉사 및 연수 </h1>
      <fieldset>
        <legend>사회 봉사</legend>
        <ul>
          <li>사회 봉사에 대한 내용을 작성</li>
          <li>사회 봉사에 대한 내용을 작성</li>
        </ul>
      </fieldset>

      <fieldset>
        <legend>해외 연수</legend>
        <ul>
          <li>해외 연수에 대한 내용을 작성</li>
          <li>해외 연수에 대한 내용을 작성</li>
        </ul>
      </fieldset>
    </div>
  );
};

export default Career2;