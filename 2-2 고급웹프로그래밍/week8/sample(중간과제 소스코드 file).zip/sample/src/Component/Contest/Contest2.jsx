import "../CSS/Contest.css";

const Contest2 = () => {
  return (
    <div>
      <h1>공모전입니다.</h1>
      <img src="/image/contest2.png" alt="react" />
      <fieldset>
        <legend>공모전 개요</legend>
        <ul>
          <li>공모전에 대한 내용을 작성</li>
          <li>공모전에 대한 내용을 작성</li>
          <li>공모전에 대한 내용을 작성</li>
          <li>공모전에 대한 내용을 작성</li>
          <li>공모전에 대한 내용을 작성</li>
        </ul>
      </fieldset>
    </div>
  );
};

export default Contest2;