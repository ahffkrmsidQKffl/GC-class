function Search() {
      return <h1>Search Page</h1>;
    }
    export default Search;