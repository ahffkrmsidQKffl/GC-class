<template>
    <div>
    <h1>Home page</h1>
    <p> 홈페이지 입니다.<br>
        Vue 파일은 실행하면 component를 생성하며,
    하나의 웹 페이지가 됩니다. </p>
    </div>
</template>
