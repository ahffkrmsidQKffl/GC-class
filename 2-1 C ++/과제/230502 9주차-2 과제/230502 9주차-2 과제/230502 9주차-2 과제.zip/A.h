#ifndef A_H
#define A_H

class A {
private :

public:
	A();
	~A();
private:
public:
	static void A1();
	static void A2();
	static void A3();

};
#endif
