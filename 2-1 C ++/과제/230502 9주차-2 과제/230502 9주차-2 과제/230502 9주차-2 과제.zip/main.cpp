#include <iostream>
#include "A.h"
#include "B.h"
#include "C.h"
using namespace std;

int main() {
	A::A2();
	B::B1();
	C::C1();

	return 0;
}