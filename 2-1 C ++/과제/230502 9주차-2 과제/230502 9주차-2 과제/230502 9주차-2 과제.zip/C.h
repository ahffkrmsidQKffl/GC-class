#ifndef C_H
#define C_H

class C {
private:
public:
	C();
	~C();
private:
public:
	static void C1();
};
#endif
