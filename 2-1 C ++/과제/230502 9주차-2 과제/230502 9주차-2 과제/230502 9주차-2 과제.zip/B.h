#ifndef B_H
#define B_H

class B {
private:
public:
	B();
	~B();
	
private:
public:
	static void B1();
	static void B2();

};
#endif
